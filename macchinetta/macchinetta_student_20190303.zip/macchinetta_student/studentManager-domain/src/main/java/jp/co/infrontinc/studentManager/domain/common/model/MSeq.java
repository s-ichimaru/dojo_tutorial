package jp.co.infrontinc.studentManager.domain.common.model;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="m_seq")
public class MSeq {

    @Embedded
    @Id
	private MSeqKey key;

	@Column(name="seq_value")
	private Long seqValue;

}
