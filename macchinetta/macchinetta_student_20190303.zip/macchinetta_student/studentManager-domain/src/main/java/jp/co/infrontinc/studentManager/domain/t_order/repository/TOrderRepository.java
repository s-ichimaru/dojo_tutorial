package jp.co.infrontinc.studentManager.domain.t_order.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import jp.co.infrontinc.studentManager.domain.t_order.model.TOrder;

public interface TOrderRepository extends JpaRepository<TOrder, String>, TOrderRepositoryCustom {

}
