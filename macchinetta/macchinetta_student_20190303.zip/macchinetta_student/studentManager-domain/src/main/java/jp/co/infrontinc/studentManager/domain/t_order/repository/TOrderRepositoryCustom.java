package jp.co.infrontinc.studentManager.domain.t_order.repository;

import jp.co.infrontinc.studentManager.domain.t_order.model.TOrder;

public interface TOrderRepositoryCustom {

	void saveForAutoId(TOrder entity);
}
