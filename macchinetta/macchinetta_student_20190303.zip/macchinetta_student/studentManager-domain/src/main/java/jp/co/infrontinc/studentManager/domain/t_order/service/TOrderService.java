package jp.co.infrontinc.studentManager.domain.t_order.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jp.co.infrontinc.studentManager.domain.t_order.model.TOrder;
import jp.co.infrontinc.studentManager.domain.t_order.repository.TOrderRepository;

@Service
@Transactional
public class TOrderService {

	@Inject
	private TOrderRepository tOrderRepository;

	public void insert(TOrder entity) {
		tOrderRepository.saveForAutoId(entity);
	}
}
