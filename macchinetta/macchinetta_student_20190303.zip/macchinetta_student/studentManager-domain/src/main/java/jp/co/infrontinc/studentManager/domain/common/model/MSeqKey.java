package jp.co.infrontinc.studentManager.domain.common.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class MSeqKey implements Serializable {

	@Column(name="seq_kbn")
	private String seqKbn;

	@Column(name="seq_key")
	private String seqKey;

	public MSeqKey() {
	}

	public MSeqKey(String kbn, String key) {
		this.seqKbn = kbn;
		this.seqKey = key;
	}

	public String getSeqKbn() {
		return seqKbn;
	}

	public void setSeqKbn(String seqKbn) {
		this.seqKbn = seqKbn;
	}

	public String getSeqKey() {
		return seqKey;
	}

	public void setSeqKey(String seqKey) {
		this.seqKey = seqKey;
	}


}
