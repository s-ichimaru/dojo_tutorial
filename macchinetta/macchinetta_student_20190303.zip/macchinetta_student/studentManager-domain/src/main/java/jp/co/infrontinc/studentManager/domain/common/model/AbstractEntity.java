package jp.co.infrontinc.studentManager.domain.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Version;

import lombok.Data;

@Data
@MappedSuperclass
public class AbstractEntity implements Serializable {

	@Column(name="created_user", updatable=false)
	private String createdUser;

	@Column(name="created_datetime", updatable=false)
//	@CreatedDate
	private Date createdDatetime;

	@Column(name="updated_user")
	private String updatedUser;

	@Column(name="updated_datetime")
//	@LastModifiedDate
	private Date updatedDatetime;

	@Version
	private Long version;

    @PrePersist
    public void onPrePersist() {
    	Date now = new Date();
    	setCreatedUser("admin"); // test
        setCreatedDatetime(now);
    	setUpdatedUser("admin"); // test
        setUpdatedDatetime(now);
    }

    @PreUpdate
    public void onPreUpdate() {
    	setUpdatedUser("admin"); // test
        setUpdatedDatetime(new Date());
    }

}
