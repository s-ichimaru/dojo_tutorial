package jp.co.infrontinc.studentManager.domain.t_order.repository;

import java.util.Date;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Repository;

import jp.co.infrontinc.studentManager.domain.common.repository.MSeqRepository;
import jp.co.infrontinc.studentManager.domain.t_order.model.TOrder;

@Repository
public class TOrderRepositoryImpl implements TOrderRepositoryCustom {

	@Inject
	private MSeqRepository mSeqRepository;

	@PersistenceContext
	EntityManager entityManager;

	public void saveForAutoId(TOrder entity) {

		String ymd = DateFormatUtils.format(new Date(), "yyyyMMdd");
		String seqkey = ymd + "_TEST";

		Long seqVal = mSeqRepository.nextVal("t_order", seqkey);
		entity.setOrderId(String.format("%s_%d", seqkey.substring(2, seqkey.length()), seqVal));

		entityManager.persist(entity);
	}

}
