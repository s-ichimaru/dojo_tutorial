package jp.co.infrontinc.studentManager.domain.common.repository;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import jp.co.infrontinc.studentManager.domain.common.model.MSeq;
import jp.co.infrontinc.studentManager.domain.common.model.MSeqKey;

@Repository
public class MSeqRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Inject
	private PlatformTransactionManager transactionManager;

	public Long nextVal(String kbn, String key) {

		java.util.List<Long> result = new ArrayList<Long>();

		TransactionTemplate template = new TransactionTemplate(transactionManager);
		template.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);

		template.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {

				MSeq seq = entityManager.find(MSeq.class, new MSeqKey(kbn, key), LockModeType.PESSIMISTIC_WRITE);
				if (seq == null) {

					MSeq newSeq = new MSeq();
					newSeq.setKey(new MSeqKey(kbn, key));
					newSeq.setSeqValue(1L);
					entityManager.persist(newSeq);
					entityManager.flush();

					result.add(1L);

				} else {
					long nextVal = seq.getSeqValue() + 1;
					seq.setSeqValue(nextVal);
					entityManager.merge(seq);
					entityManager.flush();

					result.add(nextVal);
				}

			}
		});

		return result.get(0);

	}
}
