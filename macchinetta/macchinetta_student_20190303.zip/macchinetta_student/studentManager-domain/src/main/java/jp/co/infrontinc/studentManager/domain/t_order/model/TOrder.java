package jp.co.infrontinc.studentManager.domain.t_order.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import jp.co.infrontinc.studentManager.domain.common.model.MFile;
import lombok.Data;

@Data
@Entity
@Table(name="t_order")
public class TOrder {

	@Id
	@Column(name="order_id")
	private String orderId;

	@Column(name="order_name")
	private String orderName;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="order_file_id")
	private MFile orderFile;

}
