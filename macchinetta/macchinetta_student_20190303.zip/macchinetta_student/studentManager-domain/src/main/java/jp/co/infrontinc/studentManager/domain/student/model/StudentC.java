package jp.co.infrontinc.studentManager.domain.student.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class StudentC implements Serializable {

	private String studentName;

	private String perfCd;

}
