package jp.co.infrontinc.studentManager.app.common.helper;

import javax.inject.Inject;

import org.dozer.Mapper;
import org.springframework.stereotype.Component;

@Component
public class PHelper<S, P> {

	@Inject
	protected Mapper beanMapper;

	public P s2p(S s, Class<P> clazz) {
		return beanMapper.map(s, clazz);
	}

	public S p2s(P p, Class<S> clazz) {
		return beanMapper.map(p, clazz);
	}
}
