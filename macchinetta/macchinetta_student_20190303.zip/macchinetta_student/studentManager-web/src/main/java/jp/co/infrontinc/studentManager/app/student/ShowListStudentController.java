package jp.co.infrontinc.studentManager.app.student;

import javax.inject.Inject;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import jp.co.infrontinc.studentManager.app.common.helper.CPHelper;
import jp.co.infrontinc.studentManager.app.common.helper.LPHelper;
import jp.co.infrontinc.studentManager.domain.student.model.Student;
import jp.co.infrontinc.studentManager.domain.student.model.StudentC;
import jp.co.infrontinc.studentManager.domain.student.service.StudentService;

@Controller
@RequestMapping("student")
@SessionAttributes(value = { "studentCp" })
public class ShowListStudentController {

	@Inject
	private StudentService studentService;

	@Inject
	private CPHelper<StudentC, StudentCp> cpHelper;

	@Inject
	private LPHelper<Student, StudentLp> lpHelper;

	@ModelAttribute(value = "studentCp")
	public StudentCp setupStudentCP() {
		return new StudentCp();
	}

	@GetMapping("showList")
	public String do_show(StudentCp studentCp,
			BindingResult result,
			Pageable pageable,
			Model model) {

		if (studentCp.isSearched()) {
			return do_search(studentCp, result, studentCp.getPageable(), model);
		}

		return "student/showListStudent";
	}

	@PostMapping("showList")
	public String do_search(StudentCp studentCp,
			BindingResult result,
			Pageable pageable,
			Model model) {

		StudentC studentC = cpHelper.p2s(studentCp, StudentC.class);

		Page<Student> page = studentService.findByCriteria(studentC, pageable);

		Page<StudentLp> studentLp = lpHelper.s2p(page, StudentLp.class);

		studentCp.setPageable(pageable);
		studentCp.setSearched(true);

		model.addAttribute("studentCp", studentCp);
		model.addAttribute("page", studentLp);

		return "student/showListStudent";
	}

	@GetMapping(value="showList", params={ "page", "size" })
	public String do_showPage(StudentCp studentCp,
			BindingResult result,
			Pageable pageable,
			Model model) {

		if (studentCp.isSearched()) {
			return do_search(studentCp, result, pageable, model);
		}

		return "student/showListStudent";
	}

	@GetMapping(value="showList", params="clear")
	public String do_clear(SessionStatus sessionStatus, Model model) {

		sessionStatus.setComplete();

		return "redirect:/student/showList";
	}
}
