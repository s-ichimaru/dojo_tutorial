package jp.co.infrontinc.studentManager.app.student;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class StudentLp implements Serializable {

	private String studentId;

	private String studentName;

	private String perfCd;

	private Integer age;

	private Date birthday;
}
