package jp.co.infrontinc.studentManager.app.t_order.model;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class TOrderP implements Serializable {

	private String orderId;

	@NotBlank
	private String orderName;

	private MultipartFile orderFile;

}
