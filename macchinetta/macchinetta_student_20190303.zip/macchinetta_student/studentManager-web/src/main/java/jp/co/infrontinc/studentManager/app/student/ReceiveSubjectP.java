package jp.co.infrontinc.studentManager.app.student;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;

import lombok.Data;

@Data
public class ReceiveSubjectP {

	private Integer studentId;

	@NotBlank
	private String subjectName;

    @Max(100)
    @Min(0)
    private Integer score;

}
