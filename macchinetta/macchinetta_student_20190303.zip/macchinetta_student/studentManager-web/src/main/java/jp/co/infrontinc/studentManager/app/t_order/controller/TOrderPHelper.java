package jp.co.infrontinc.studentManager.app.t_order.controller;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import jp.co.infrontinc.studentManager.app.common.helper.PHelper;
import jp.co.infrontinc.studentManager.app.t_order.model.TOrderP;
import jp.co.infrontinc.studentManager.domain.common.model.MFile;
import jp.co.infrontinc.studentManager.domain.t_order.model.TOrder;

@Component
public class TOrderPHelper extends PHelper<TOrder, TOrderP> {
/*
	@Override
	public TOrderP s2p(TOrder s, Class<TOrderP> clazz) {
		TOrderP tOrderP = super.s2p(s, clazz);
		return tOrderP;
	}
*/

	@Override
	public TOrder p2s(TOrderP p, Class<TOrder> clazz) {
		TOrder tOrder = super.p2s(p, clazz);

		try {

			MFile file = new MFile();
			MultipartFile fileP = p.getOrderFile();

			file.setFileName(fileP.getName());
			file.setFileData(fileP.getBytes());

			tOrder.setOrderFile(file);

		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return tOrder;
	}

}
