package jp.co.infrontinc.studentManager.app.common.helper;

import javax.inject.Inject;

import org.dozer.Mapper;
import org.springframework.stereotype.Component;

@Component
public class CPHelper<C, CP> {

	@Inject
	protected Mapper beanMapper;

	public CP s2p(C c, Class<CP> clazz) {
		return beanMapper.map(c, clazz);
	}

	public C p2s(CP cp, Class<C> clazz) {
		return beanMapper.map(cp, clazz);
	}

}
