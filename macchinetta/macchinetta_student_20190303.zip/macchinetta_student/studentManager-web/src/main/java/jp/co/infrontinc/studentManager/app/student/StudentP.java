package jp.co.infrontinc.studentManager.app.student;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class StudentP implements Serializable {

	private Integer studentId;

	@NotNull
	@NotBlank
	private String studentName;

	@NotNull
	@NotBlank
	private String perfCd;

	@NotNull
	@Min(1)
	@Max(20)
	private Integer age;

	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date birthday;

	private Long version;

	@Valid
	private List<ReceiveSubjectP> receiveSubjectList = new ArrayList<ReceiveSubjectP>();
}
