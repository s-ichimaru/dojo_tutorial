create table t_order (
order_id varchar(14),
order_name varchar(30),
order_file_id bigint,
primary key(order_id)
);

create table t_order_detail (
order_id varchar(14),
year integer,
month integer,
user_id integer,
pay_amount numeric(13,0),
jisseki_amout numeric(13,0),
primary key(order_id, year, month, user_id),
FOREIGN KEY (order_id) REFERENCES t_order(order_id)
);

create table m_file (
file_id bigint,
file_name varchar(255),
file_data bytea,
primary key(file_id)
);

create table m_seq(
seq_kbn varchar(255),
seq_key varchar(255),
seq_value bigint,
primary key(seq_kbn, seq_key)
);

CREATE SEQUENCE file_id_seq