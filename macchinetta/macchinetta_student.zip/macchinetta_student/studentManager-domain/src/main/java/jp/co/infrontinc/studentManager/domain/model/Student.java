package jp.co.infrontinc.studentManager.domain.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import jp.co.infrontinc.studentManager.domain.common.model.AbstractEntity;
import lombok.Data;

@Data
@Entity
@Table(name = "t_student")
public class Student extends AbstractEntity {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "student_id_seq")
    @SequenceGenerator(name = "student_id_seq", sequenceName = "student_id_seq", allocationSize = 1)
	@Column(name="student_id")
	private Integer studentId;

	@Column(name="student_name")
	private String studentName;

	@Column(name="perf_cd")
	private String perfCd;

	@Column
	private Integer age;

	@Column
	private Date birthday;

}
