package jp.co.infrontinc.studentManager.app.student;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.terasoluna.gfw.common.message.ResultMessage;
import org.terasoluna.gfw.common.message.ResultMessages;

import jp.co.infrontinc.studentManager.app.common.helper.PHelper;
import jp.co.infrontinc.studentManager.domain.model.Student;
import jp.co.infrontinc.studentManager.domain.service.StudentService;

@Controller
@RequestMapping("student")
public class InsertStudentController {

	@Inject
	private StudentService studentService;

	@Inject
	private PHelper<Student, StudentP> pHelper;

	@ModelAttribute
	public StudentP setupForm() {
		return new StudentP();
	}

	@GetMapping("insert")
	public String do_show() {
		return "student/insertStudent";
	}

	@PostMapping("insert")
	public String do_insert(@Validated StudentP studentP,
			BindingResult result,
			RedirectAttributes attributes) {

		if (result.hasErrors()) {
			return "student/insertStudent";
		}

		Student student = pHelper.p2s(studentP, Student.class);

		studentService.create(student);

		attributes.addFlashAttribute(ResultMessages.success().add(
				ResultMessage.fromText("登録が完了しました。")));

		return "redirect:/student/insert";
	}
}
