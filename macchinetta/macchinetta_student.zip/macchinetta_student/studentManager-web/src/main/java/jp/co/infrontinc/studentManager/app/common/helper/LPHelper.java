package jp.co.infrontinc.studentManager.app.common.helper;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.dozer.Mapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

@Component
public class LPHelper<S, LP> {

	@Inject
	protected Mapper beanMapper;

	public List<LP> s2p(List<S> ls, Class<LP> clazz) {

		List<LP> lp = new ArrayList<LP>();
		for(S s : ls) {
			lp.add(beanMapper.map(s, clazz));
		}
		return lp;
	}

	public Page<LP> s2p(Page<S> ls, Class<LP> clazz) {

		Pageable p = new PageRequest(ls.getNumber(), ls.getSize(), ls.getSort());
		List<LP> content = s2p(ls.getContent(), clazz);
		return new PageImpl<LP>(content, p, ls.getTotalElements());
	}
}
