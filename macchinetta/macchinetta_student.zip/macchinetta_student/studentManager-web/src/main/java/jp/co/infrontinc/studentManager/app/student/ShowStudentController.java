package jp.co.infrontinc.studentManager.app.student;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jp.co.infrontinc.studentManager.app.common.helper.PHelper;
import jp.co.infrontinc.studentManager.domain.model.Student;
import jp.co.infrontinc.studentManager.domain.service.StudentService;

@Controller
@RequestMapping("student")
public class ShowStudentController {

	@Inject
	private StudentService studentService;

	@Inject
	private PHelper<Student, StudentP> pHelper;

	@GetMapping("show")
	public String do_show(@RequestParam("studentId") Integer studentId, Model model) {

		Student student = studentService.findOne(studentId);

		StudentP studentP = pHelper.s2p(student, StudentP.class);

		model.addAttribute("studentP", studentP);

		return "student/showStudent";
	}

}
