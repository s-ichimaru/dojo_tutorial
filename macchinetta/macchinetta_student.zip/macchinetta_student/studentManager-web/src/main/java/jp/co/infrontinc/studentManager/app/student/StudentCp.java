package jp.co.infrontinc.studentManager.app.student;

import java.io.Serializable;

import org.springframework.data.domain.Pageable;

import lombok.Data;

@Data
public class StudentCp implements Serializable {

	private String studentName;

	private String perfCd;

	private Pageable pageable;

	private boolean isSearched;
}
