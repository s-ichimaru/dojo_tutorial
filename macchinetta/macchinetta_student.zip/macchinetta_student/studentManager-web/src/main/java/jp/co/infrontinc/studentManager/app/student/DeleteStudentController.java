package jp.co.infrontinc.studentManager.app.student;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.terasoluna.gfw.common.message.ResultMessage;
import org.terasoluna.gfw.common.message.ResultMessages;

import jp.co.infrontinc.studentManager.domain.service.StudentService;

@Controller
@RequestMapping("student")
public class DeleteStudentController {

	@Inject
	private StudentService studentService;

	@PostMapping("delete")
	public String do_delete(@RequestParam("studentId") Integer studentId, RedirectAttributes attributes) {

		studentService.delete(studentId);

		attributes.addFlashAttribute(ResultMessages.success().add(
				ResultMessage.fromText("削除が完了しました。")));

		return "redirect:/student/showList";
	}
}
