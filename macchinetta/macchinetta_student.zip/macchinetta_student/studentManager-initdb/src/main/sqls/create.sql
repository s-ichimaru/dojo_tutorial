create table t_student (
    student_id integer,
    student_name varchar(30),
    perf_cd varchar(2),
    age integer,
    birthday date,
    created_user varchar(30) not null,
    created_datetime timestamp not null,
    updated_user varchar(30),
    updated_datetime timestamp,
    version integer,
    primary key(student_id)
)

create table m_perf (
	perf_cd varchar(2),
	perf_name varchar(30),
	created_user varchar(30),
	created_datetime timestamp,
	updated_user varchar(30),
	updated_datetime timestamp,
	version integer,
	primary key(perf_cd)
)